# Verification and execution
Identify exact work repo and checkpoint. Check version-matched sources. Run relevant tests, inspect logs, verify commit and update project handoff. Never claim device tests or deployments without evidence.
