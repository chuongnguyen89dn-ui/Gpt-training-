Skill package: 04-ci-cd-render-cloud
Read SKILL.md. Verify repo and environment before executing.
