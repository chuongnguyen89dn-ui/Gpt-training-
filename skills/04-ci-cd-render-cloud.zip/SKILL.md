# GitHub Actions, Render and Cloud Deployment Skill
TRIGGER: workflow, build failed, Render, deploy, cloud hosting, manifest, API, environment.
1. Identify target repo, workflow file, branch, trigger, last green run and failing run; inspect full relevant job logs and dependency/toolchain versions.
2. Distinguish workflow syntax, checkout/permissions, missing secrets, dependency resolution, compile, packaging, artifact upload and deployment failures.
3. Prefer smallest safe fix and run the narrowest test; do not edit unrelated workflows or replace working config.
4. Inspect Render service linked repo, deploy commit, runtime, health endpoint, logs, env variable names (not secret values), scaling/sleep and resource constraints.
5. Verify actual endpoint content, manifest JSON and freshness. HTTP 200 alone is not proof that catalog or streams are valid.
6. Avoid expensive background scans unless authorized. For schedules, preserve existing cadence and resource limits.
7. Publish only to the requested service; distinguish source commit, workflow success, deploy success and functional acceptance.
8. Preserve rollback target, previous healthy version, test evidence and handoff.
