# GitHub Continuity and Evidence Skill
TRIGGER: resume, continue, handoff, repo, branch, status, commits, GitHub Actions.
1. Resolve project identity from user request, then confirm repository full name, default/active branch, latest commit and permissions. Never mix project repositories.
2. Locate the existing handoff by filename/path search, including tiep tuc du an, WORK_HANDOFF and project-specific equivalents. Read full relevant sections and referenced scripts; preserve earlier decisions.
3. Compare handoff checkpoint to actual GitHub commit, workflows, run logs, Releases and source. Distinguish historical success from current status.
4. Record an execution lock: repo, branch, commit, task, environment, expected artifact, publish destination, last proven step, next action.
5. For new changes: minimal diff, test, commit, verify remote SHA and re-fetch changed file. Never report success from a proposed change.
6. Handoff only meaningful events: decisions, code changes, tests, build results, blockers, deployment. Use CONFIRMED, UNVERIFIED, USER_DECISION, SUPERSEDED.
7. Persist reproducible scripts, commands, config templates, relevant logs and outputs. Never commit tokens, keys, credentials or personal data.
8. If binary upload is blocked, prefer native GitHub Release for distribution; otherwise use lossless Base64 chunks, SHA256 manifest and recovery script. Never rename binary to TXT and call it equivalent.
9. If no work repo exists, ask to create one or obtain permission for a shared handoff repo. Keep the central skill repo read-only except for skill maintenance.
VERIFICATION: exact file URLs, commit SHA, test evidence, next step. Do not invent device-test evidence.
