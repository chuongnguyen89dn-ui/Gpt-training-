Skill package: 01-github-continuity
Read SKILL.md. Verify repo and environment before executing.
