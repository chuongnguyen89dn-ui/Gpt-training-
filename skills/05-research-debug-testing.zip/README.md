Skill package: 05-research-debug-testing
Read SKILL.md. Verify repo and environment before executing.
