# Multi-source Research, Debugging and Testing Skill
TRIGGER: unclear failure, unfamiliar SDK/API, repeated fixes, architectural choice, regression.
Read project history and previously successful/failed attempts before proposing changes. Establish exact environment, version and reproducible failing input.
Research official docs, upstream source, release notes, issues and comparable projects. Prefer recent version-matched primary evidence over forum speculation.
Write a falsifiable hypothesis and a minimal reproduction. Change one variable at a time; capture baseline and after-state.
Prioritize tests: syntax/static checks, unit, integration, package inspection, deployment smoke test, physical device test if available. Mark unavailable tests explicitly.
Check backward compatibility, performance, resource cost, security and rollback. Do not break an unrelated profile, split UI or player to fix another.
Stop repeated attempts that produce identical failures; gather new evidence before retry.
Return concise action/result/evidence/next step; never claim a test passed without running it.
