# Python Crawler, Catalog and Resolver Skill
TRIGGER: Python crawl, scan, metadata, poster, pagination, resolver, HLS, JSON catalog.
FIRST: find prior working script and exact command, fixture, log, URL patterns, successful sample and current exclusion filters. Do not restart a full scan before reproducing a known working sample.
FETCH: use requests/httpx or browser automation only as justified. Handle timeout, retry with backoff, redirects, rate limits, status codes and encoding. Respect authorization and service rules.
PARSE: validate selectors, canonical IDs, pagination, metadata, poster URL, quality filters, deduplication and source provenance. Never fabricate IDs or URLs.
TEST: test 1 item, 20-item sample, then full crawl. Compare counts, quality, metadata completeness and duplicates; save machine-readable validation report.
DATA: use atomic writes, checkpoints/resume, schema version, incremental merges and backups. Never erase a working catalog without explicit permission.
HLS: distinguish master/media playlist, VOD ENDLIST, duration and seek behavior; verify URL accessibility and actual playback separately.
DEPLOY: verify generated catalog and manifest in repository, then remote deployment and API response. A green build alone does not prove add-on visibility or playback.
REPORT: actual counts and commands, success/failure examples, exact next action.
