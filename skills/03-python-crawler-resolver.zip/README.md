Skill package: 03-python-crawler-resolver
Read SKILL.md. Verify repo and environment before executing.
