Skill package: 06-artifact-zip-handoff
Read SKILL.md. Verify repo and environment before executing.
