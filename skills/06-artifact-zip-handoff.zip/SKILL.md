# Artifact Persistence and ZIP Recovery Skill
TRIGGER: ZIP, DEB, IPA, binary upload, deliverables, cross-chat handoff.
Every meaningful project artifact belongs in its own project repo or explicitly approved shared handoff repo. The central Gpt-training repo stores only reusable skill packages.
For each artifact: record original filename, source commit, byte size, SHA256, build/test command, compatibility and storage path.
Try native supported binary upload, GitHub Release or Git LFS when appropriate. If the connector accepts only text, losslessly Base64 encode original bytes, split numbered chunks under tool size limits and provide MANIFEST.json plus restore.py. Verify decoded SHA256 equals original.
Never substitute a prose summary for source code, scripts or binary bytes. If full preservation is impossible, report the gap honestly.
For ZIP skill packages, keep both an actual ZIP and readable extracted Markdown index when possible. The agent should discover skill ZIP by feature in Gpt-training and inspect actual contents before using it.
Never include passwords, API tokens, signing certificates, private keys or sensitive logs. Never upload unnecessary temporary files.
Handoff checkpoint: target repo, branch/commit, exact task, completed steps with evidence, active blocker, next command, artifact links and test state.
