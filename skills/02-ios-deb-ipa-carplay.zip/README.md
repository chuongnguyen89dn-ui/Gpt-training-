Skill package: 02-ios-deb-ipa-carplay
Read SKILL.md. Verify repo and environment before executing.
