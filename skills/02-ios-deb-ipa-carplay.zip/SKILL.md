# iOS DEB, IPA, CarPlay Build Skill
TRIGGER: jailbreak, tweak, DuoFace, DuoDash, DEB, IPA, Sileo, rootless, CarPlay.
PRECHECK: confirm target iPhone/iOS/jailbreak architecture, rootless vs rootful, build host, toolchain, repo/branch, upstream baseline and feature constraints.
DEB: inspect Debian control metadata, package filesystem, pre/postinst scripts, dylib/app bundle paths, architecture, rootless prefix, dependencies, launch hooks, signing and entitlements. Verify dpkg-deb contents before publishing.
IPA: inspect Xcode project/workspace, Swift/ObjC dependencies, target deployment, signing/provisioning, bundle identifiers, entitlements and build workflow. Separate compile success from signing and installation.
CarPlay: preserve original app picker, split ratio drag, dock and UI unless user requests change. Check target display geometry and simulator dimensions; do not claim real-car testing from screenshots.
BUILD PIPELINE: source diff -> compile -> package -> inspect archive -> GitHub Actions artifact -> optional Release/Sileo repo -> installation -> device validation. Record evidence at each stage.
REPRODUCE: use existing working pipeline first; isolate regression; build only after meaningful fix. Save commands and logs with secrets removed.
RELEASE: confirm package identity, version, architecture, repository metadata and checksum. No silent overwrite of existing release.
FAILURES: compare current failing job against most recent green run and exact commit; inspect compiler errors rather than guessing. Distinguish toolchain unavailable from code failure.
